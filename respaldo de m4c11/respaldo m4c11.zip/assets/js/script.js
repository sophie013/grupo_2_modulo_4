// 🎧 AUDIO PLAYER WINAMP FUNCIONAL
const audioPlayer = document.getElementById("audio-player");
const playBtn = document.getElementById("play-btn");
const pauseBtn = document.getElementById("pause-btn");
const stopBtn = document.getElementById("stop-btn");

playBtn.addEventListener("click", () => {
    audioPlayer.play();
});

pauseBtn.addEventListener("click", () => {
    audioPlayer.pause();
});

stopBtn.addEventListener("click", () => {
    audioPlayer.pause();
    audioPlayer.currentTime = 0;
});

// 🍔 NAVBAR HAMBURGUESA
const hamburgerBtn = document.getElementById("hamburger-btn");
const navLinks = document.getElementById("nav-links");

hamburgerBtn.addEventListener("click", () => {
    navLinks.classList.toggle("active");
});

// 🛍️ CATÁLOGO + CARRITO + FAVORITOS
const productos = [
    { id: 1, nombre: "Pulsera Neón", precio: 2500 },
    { id: 2, nombre: "Cinturón de Cadenas", precio: 8000 },
    { id: 3, nombre: "Polera Negativa", precio: 12000 },
    { id: 4, nombre: "Pantalón Rasgado", precio: 18000 }
];

let carrito = [];
let favoritos = [];

const catalogo = document.getElementById("catalogo-list");
const carritoCount = document.getElementById("carrito-count");
const carritoTotal = document.getElementById("carrito-total");

function renderProductos() {
    catalogo.innerHTML = "";

    productos.forEach(producto => {
        const card = document.createElement("div");
        card.classList.add("product-card");

        card.innerHTML = `
            <h4>${producto.nombre}</h4>
            <p>$${producto.precio}</p>
            <button class="btn-fav" onclick="toggleFavorito(${producto.id})">❤️</button>
            <br><br>
            <button class="btn-add" onclick="agregarAlCarrito(${producto.id})">+ Agregar</button>
        `;

        catalogo.appendChild(card);
    });
}

function agregarAlCarrito(id) {
    const producto = productos.find(p => p.id === id);
    carrito.push(producto);
    actualizarCarrito();
}

function actualizarCarrito() {
    carritoCount.textContent = carrito.length;
    const total = carrito.reduce((sum, p) => sum + p.precio, 0);
    carritoTotal.textContent = "$" + total;
}

function toggleFavorito(id) {
    if (favoritos.includes(id)) {
        favoritos = favoritos.filter(f => f !== id);
    } else {
        favoritos.push(id);
    }
}

// ⚡ ZUMBIDO MSN
function darZumbido() {
    const ventana = document.getElementById("main-window");
    ventana.classList.add("shake");
    setTimeout(() => {
        ventana.classList.remove("shake");
    }, 600);
}

function realizarPedidoWeb() {
    alert("💖 Pedido enviado al estilo 2007!");
}

// Render inicial
renderProductos();