tienda de modas urbanas vintage para modas que vuelven e.e
(harlem shake de fondo)
everyday im shuffleling :v

i need a hero 


navbar tipo anvorguesa (ñam)


emos (no era una etapa :V )
gyaru 
therian (wtf)
otakus (para reprimidos y valientes)
pokemones (que ya no bailan hasta el suelo, tenemos rodillas de repuesto)
visual ?



elementos de venta (merchandising)


ropa
pantalones 
accesorios, chapas, pins, collares con puas, carteras, bolsos, mochilas
extensiones
skins therian
lentes 
vestidos lolita 
vestidos visual 


maquillaje mixto (miramos y no juzgamos) 

accesorios
correas de perro para therian xd
cerveza therian
galletas therian 


carrousel de imagenes 









foooter 




webs inspiracion https://www.vntgcat.cl/ 

https://www.etsy.com/market/frutiger_aero_clothing

